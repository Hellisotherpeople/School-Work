Michael McGirr
mmcgirr@cs.uoregon.edu

To compile (I've included a Makefile) run: make
To run recursive program: ./PrintNeatRecursiveTopDown < yourSampleInput.txt
To run dynamic programming version: ./PrintNeatIterativeBottomUp < yourSampleInput.txt
