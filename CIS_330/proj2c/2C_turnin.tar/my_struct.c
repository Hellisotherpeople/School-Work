/* This file should contain the 9 functions defined in prototypes.h */

#include <prototypes.h>

void InitializeRectangle(Rectangle* rectangle, double minX, double maxX, double minY, double maxY)
{
 //Rectangle t;
 rectangle->minX = minX; 
 rectangle->minY = minY;
 rectangle->maxX = maxX; 
 rectangle->maxY = maxY; 
}

double GetRectangleArea(Rectangle* rectangle)
{
    return ((rectangle->maxX - rectangle->minX) * (rectangle->maxY - rectangle->minY));
}

void GetRectangleBoundingBox(Rectangle * rectangle, double * Bbox)
{
    Bbox[0] = rectangle->minX;
    Bbox[1] = rectangle->maxX;
    Bbox[2] = rectangle->minY; 
    Bbox[3] = rectangle->maxY;
}


void InitializeCircle(Circle * circle, double radius, double origin, double originY)
{
    circle->radius = radius; 
    circle->origin = origin; 
    circle->originY = originY; 
}

double GetCircleArea(Circle * circle)
{
    return ((3.14159 * circle->radius * circle->radius));
}


void GetCircleBoundingBox(Circle * circle, double * Bbox)
{
    Bbox[0] = (circle->origin - circle->radius); 
    Bbox[1] = (circle->origin + circle->radius);
    Bbox[2] = (circle->originY - circle->radius);
    Bbox[3] = (circle->originY + circle->radius); 
}

void InitializeTriangle(Triangle * triangle, double pt1X, double pt2X, double minY, double maxY)
{
    triangle->pt1X = pt1X;
    triangle->pt2X = pt2X; 
    triangle->minY = minY;
    triangle->maxY = maxY; 
}


double GetTriangleArea(Triangle * triangle)
{
    return (((triangle->pt2X - triangle->pt1X) * (triangle->maxY - triangle->minY)/2));
}


void GetTriangleBoundingBox(Triangle * triangle, double * Bbox)
{
    Bbox[0] = triangle->pt1X; 
    Bbox[1] = triangle->pt2X; 
    Bbox[2] = triangle->minY;
    Bbox[3] = triangle->maxY;
}    